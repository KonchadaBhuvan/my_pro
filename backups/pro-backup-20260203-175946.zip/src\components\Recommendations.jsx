import React from 'react';
import { useAuth } from '../context/useAuth';

export default function Recommendations() {
  const { searchResults, incrementSolved, setSearchResults } = useAuth();

  function handleSolved(id) {
    incrementSolved(1);
    if (!searchResults) return;
    const remaining = searchResults.results.filter(r => r.id !== id);
    setSearchResults({ ...searchResults, results: remaining });
  }

  return (
    <aside className="recommendations card">
      <h3>Recommendations</h3>

      {searchResults && searchResults.results.length > 0 ? (
        <ul className="recommendation-list" style={{marginTop:12}}>
          {searchResults.results.map(r => (
            <li key={r.id} className="recommendation-item">
              <div>
                <strong>{r.title}</strong>
                <div className="muted small">{r.source}</div>
              </div>
              <div style={{display:'flex',gap:8}}>
                <a className="secondary-btn" href={r.url} target="_blank" rel="noreferrer">Open</a>
                <button className="btn" onClick={() => handleSolved(r.id)}>Solved</button>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="muted" style={{marginTop:12}}>No search results yet — paste a problem and click Analyze.</div>
      )}
    </aside>
  );
}
