import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from './context';

function loadJson(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch { return fallback; }
}

function saveJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function AuthProvider({ children }) {
  const navigate = useNavigate();
  const [users, setUsers] = useState(() => loadJson('pro_users', {}));
  const [current, setCurrent] = useState(() => loadJson('pro_current', null));
  const [searchResults, setSearchResults] = useState(null);

  // derive current user & API key from stored values
  const user = current ? users[current] : null;
  const apiKey = current ? localStorage.getItem('pro_api_' + current) : null;

  useEffect(() => { saveJson('pro_users', users); }, [users]);
  useEffect(() => { localStorage.setItem('pro_current', current); }, [current]);

  // Auth actions
  function register({ name, email, password }) {
    if (!email) return { ok:false, error:'Email required' };
    if (users[email]) return { ok:false, error:'User already exists' };
    const newUser = { name, email, password, stats: { problemsSolved:0 } };
    setUsers(prev=>({ ...prev, [email]: newUser }));
    setCurrent(email);
    return { ok:true };
  }

  function login({ email, password }) {
    const u = users[email];
    if (!u) return { ok:false, error:'No user found' };
    if (u.password !== password) return { ok:false, error:'Invalid password' };
    setCurrent(email);
    return { ok:true };
  }

  function logout() {
    setCurrent(null);
    setSearchResults(null);
    navigate('/auth');
  }

  // API key
  function setApiKey(key) {
    if (!current) return;
    localStorage.setItem('pro_api_' + current, key);
  }

  // Simple simulated search — replace this with actual Gemini API integration.
  async function searchProblem(text) {
    // If no API key present, return simulated results and indicate missing key
    const key = apiKey || null;
    // Simulate network delay
    await new Promise(r => setTimeout(r, 600));

    // If you want to integrate Gemini, replace this block with an actual fetch to their API using `key`.

    const sample = [
      { id: 'r1', title: `StackOverflow - ${text.slice(0,40)}`, url: `https://stackoverflow.com/search?q=${encodeURIComponent(text)}`, source:'StackOverflow' },
      { id: 'r2', title: `GitHub - ${text.slice(0,30)}`, url: `https://github.com/search?q=${encodeURIComponent(text)}`, source:'GitHub' },
      { id: 'r3', title: `MDN - ${text.slice(0,30)}`, url: `https://developer.mozilla.org/en-US/search?q=${encodeURIComponent(text)}`, source:'MDN' },
      { id: 'r4', title: `Blog post about ${text.split(' ')[0] || 'topic'}`, url: '#', source:'Blog' }
    ];

    const payload = { engine: key ? 'gemini' : 'simulated', results: sample, apiKeyPresent: !!key };
    setSearchResults(payload);
    return payload;
  }

  function incrementSolved(by = 1) {
    if (!current) return;
    setUsers(prev => {
      const u = prev[current];
      const updated = { ...u, stats: { ...u.stats, problemsSolved: (u.stats.problemsSolved || 0) + by } };
      const next = { ...prev, [current]: updated };
      saveJson('pro_users', next);
      return next;
    });
  }

  return (
    <AuthContext.Provider value={{
      users, current, user, apiKey, searchResults,
      register, login, logout, setApiKey, searchProblem, incrementSolved,
      setSearchResults
    }}>
      {children}
    </AuthContext.Provider>
  );
}


