import React, { useState } from 'react';
import { useAuth } from '../context/useAuth';

export default function ProblemInput() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);
  const { searchProblem } = useAuth();

  async function handleSubmit(e) {
    e.preventDefault();
    if (!text.trim()) { setMsg('Please enter something to search.'); return; }
    setLoading(true); setMsg(null);
    try {
      const res = await searchProblem(text.trim());
      if (!res.apiKeyPresent) setMsg('No API key set — showing simulated results. Set API key in the header for real results.');
    } catch (error) {
      console.error(error);
      setMsg('Search failed.');
    } finally { setLoading(false); }
  }

  function handleClear() { setText(''); setMsg(null); }

  return (
    <section className="card problem-input">
      <h3>Problem Input</h3>

      <form onSubmit={handleSubmit}>
        <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Describe your problem, paste code or a link..." />

        <div className="input-row" style={{marginTop:10}}>
          <button type="submit" className="btn" disabled={loading}>{loading ? 'Searching...' : 'Analyze'}</button>
          <button type="button" className="secondary-btn" onClick={handleClear}>Clear</button>
          <span className="muted" style={{marginLeft:10}}>Tip: paste a problem description or a code snippet</span>
        </div>
      </form>

      {msg && (
        <div className="card mt result-box">
          <p className="muted" style={{marginTop:6}}>{msg}</p>
        </div>
      )}
    </section>
  );
}
