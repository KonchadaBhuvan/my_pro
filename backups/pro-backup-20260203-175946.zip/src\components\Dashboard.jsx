import React from 'react';
import { useAuth } from '../context/useAuth';

export default function Dashboard() {
  const { user, incrementSolved } = useAuth();
  const solved = user?.stats?.problemsSolved || 0;

  return (
    <section className="dashboard">
      <h2>Dashboard</h2>

      <div className="stat-grid" style={{marginTop:12}}>
        <div className="stat-card card">
          <div className="stat-value">{solved}</div>
          <div className="muted">Problems Solved</div>
        </div>
        <div className="stat-card card">
          <div className="stat-value">{Math.min(95, 50 + solved)}%</div>
          <div className="muted">Average Accuracy</div>
        </div>
        <div className="stat-card card">
          <div className="stat-value">{Math.round(solved * 0.5)}h</div>
          <div className="muted">Time Saved</div>
        </div>
      </div>

      <div className="card mt">
        <h4 style={{margin:0}}>Recent Activity</h4>
        <ul className="muted" style={{marginTop:8}}>
          <li>Analyzed problem: sample analysis</li>
          <li>Suggested improvement: UI polish</li>
        </ul>

        <div style={{marginTop:10}}>
          <button onClick={() => incrementSolved(1)} className="btn">Mark test solved</button>
        </div>
      </div>
    </section>
  );
}
