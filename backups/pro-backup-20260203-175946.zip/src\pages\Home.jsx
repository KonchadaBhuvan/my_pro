import React from 'react';
import Navbar from '../components/Navbar';
import ProblemInput from '../components/ProblemInput';
import Recommendations from '../components/Recommendations';

export default function Home() {
  return (
    <div className="home">
      <Navbar />

      <div className="container">
        <main className="main-grid">
          <section className="left">
            <ProblemInput />
          </section>
          <aside className="right">
            <Recommendations />
          </aside>
        </main>
      </div>
    </div>
  );
}
