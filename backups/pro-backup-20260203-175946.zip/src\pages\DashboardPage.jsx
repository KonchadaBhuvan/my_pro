import React from 'react';
import Navbar from '../components/Navbar';
import Dashboard from '../components/Dashboard';

export default function DashboardPage() {
  return (
    <div className="dashboard-page">
      <Navbar />
      <div className="container" style={{marginTop:20}}>
        <h1>Dashboard</h1>
        <Dashboard />
      </div>
    </div>
  );
}
