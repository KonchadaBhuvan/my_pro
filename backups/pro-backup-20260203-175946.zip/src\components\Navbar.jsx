import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/useAuth';

export default function Navbar() {
  const { user, logout, apiKey, setApiKey } = useAuth();
  const [showKey, setShowKey] = useState(false);
  const [keyInput, setKeyInput] = useState(apiKey || '');

  function saveKey() {
    setApiKey(keyInput);
    setShowKey(false);
  }

  return (
    <header className="navbar container" role="banner">
      <div className="header-left">
        <Link to="/" className="logo" aria-label="pro home">
          <span className="logo-mark">pro</span>
        </Link>
      </div>

      <nav className="nav-links" role="navigation" aria-label="Main">
        <Link to="/" className="nav-link">Home</Link>
        {user && <Link to="/dashboard" className="nav-link">Dashboard</Link>}
        <Link to="/auth" className="nav-link">Auth</Link>
        <a className="nav-link" href="#features">Features</a>
      </nav>

      <div className="header-right">
        <button className="btn" title="Create new">New</button>

        {user ? (
          <>
            <button className="secondary-btn" onClick={()=>setShowKey(s=>!s)}>{apiKey ? 'API key set' : 'Set API key'}</button>
            <button className="profile-btn" aria-label="Profile" title="Sign out" onClick={logout}>{(user.name||user.email).slice(0,2).toUpperCase()}</button>
          </>
        ) : (
          <Link to="/auth" className="secondary-btn">Sign in</Link>
        )}

        {showKey && (
          <div style={{position:'absolute', right:20, top:64, width:320}} className="card">
            <div style={{display:'flex',gap:8}}>
              <input value={keyInput} onChange={e=>setKeyInput(e.target.value)} placeholder="Paste Gemini API key..." style={{flex:1,padding:8,borderRadius:8,border:'1px solid rgba(15,23,42,0.06)'}} />
              <button className="btn" onClick={saveKey}>Save</button>
            </div>
            <div className="muted small" style={{marginTop:8}}>We store the API key locally only to use with requests from this browser.</div>
          </div>
        )}
      </div>
    </header>
  );
}
